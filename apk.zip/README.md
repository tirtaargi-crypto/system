# System Update Demo

A minimal Android demo project for building a debug APK with Gradle.

This is a harmless local demo and does not perform system updates, persistence, anti-debugging, or stealth behavior.
